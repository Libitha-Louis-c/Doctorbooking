﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Doctorbooking
{
    public partial class login : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void loginButton_Click(object sender, EventArgs e)
        {
            //if(txtusr.Text=="admin@mysite.com" && txtpwd.Text=="123")
            //{
            //    System.Web.Security.FormsAuthentication.RedirectFromLoginPage(txtusr.Text, false);
            //}

            bookingdbEntities1 db = new bookingdbEntities1();
            if (chkadn.Checked)
            {
                usertab d = db.usertabs.FirstOrDefault(f => f.email == txtusr.Text && f.pwd == txtpwd.Text);
               
                Session["role"] = "admin";
                Session["id"] = d.Id;
            }
            else if(chkdr.Checked)
            {
                doctor d = db.doctors.FirstOrDefault(f => f.email == txtusr.Text && f.pwd == txtpwd.Text);
               
                Session["role"] = "doctor";
                Session["id"] = d.docId;
            }
            else 
            {
                patientreg d = db.patientregs.FirstOrDefault(f => f.email == txtusr.Text && f.password == txtpwd.Text);
                
                Session["role"] = "patient";
                Session["id"] = d.pid;
            }
            if (Session["id"] == null)
            {

                lblmsg.InnerText = "Error occurred.please try again later";
                return;
            }
            System.Web.Security.FormsAuthentication.RedirectFromLoginPage(txtusr.Text, false);

        }
    }
}